# chat-app-api

This project consists of website that can be used to chat with people, post photos ,videos and so on in social feed.
This project is in progress.
Client side repo : https://github.com/sanjaymajhi/chat-app-client
